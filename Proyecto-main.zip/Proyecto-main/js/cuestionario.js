// Cuestionario sobre el Beato David Carlos de Vergara Marañón

function comprobar() {
  let puntaje = 0;

  // Selección de la opción marcada en cada pregunta
  let p1 = document.querySelector('input[name="p1"]:checked');
  let p2 = document.querySelector('input[name="p2"]:checked');
  let p3 = document.querySelector('input[name="p3"]:checked');
  let p4 = document.querySelector('input[name="p4"]:checked');
  let p5 = document.querySelector('input[name="p5"]:checked');
  let p6 = document.querySelector('input[name="p6"]:checked');
  let p7 = document.querySelector('input[name="p7"]:checked');

  // Si alguna pregunta no fue respondida, avisamos y salimos
  if (!p1 || !p2 || !p3 || !p4 || !p5 || !p6 || !p7) {
    document.getElementById("resultado").innerHTML =
      "Debes responder las siete preguntas.";
    return;
  }

  // Respuestas correctas
  if (p1.value === "b") puntaje++;
  if (p2.value === "c") puntaje++;
  if (p3.value === "a") puntaje++;
  if (p4.value === "b") puntaje++;
  if (p5.value === "c") puntaje++;
  if (p6.value === "b") puntaje++;
  if (p7.value === "a") puntaje++;

  let mensaje = "<h3>Resultado: " + puntaje + "/7 puntos</h3>";

  if (puntaje === 7) {
    mensaje += "¡Felicitaciones! Has respondido correctamente todas las preguntas.";
  } else if (puntaje >= 5) {
    mensaje += "Muy bien. Conoces bastante sobre la vida del Beato David.";
  } else {
    mensaje += "Te invito a leer nuevamente las secciones e intentarlo otra vez.";
  }

  document.getElementById("resultado").innerHTML = mensaje;
}

function reiniciar() {
  let opciones = document.querySelectorAll('input[type="radio"]');

  for (let opcion of opciones) {
    opcion.checked = false;
  }

  document.getElementById("resultado").innerHTML = "";
}
